@extends('layouts.public')
@section('content')
    <livewire:public.post.index :taxonomy="$taxonomy">
@endsection

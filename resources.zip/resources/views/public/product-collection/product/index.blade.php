@extends('layouts.public')
@section('content')
    <livewire:public.product.index :category="$category">
@endsection

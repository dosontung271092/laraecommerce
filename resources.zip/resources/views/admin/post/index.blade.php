@extends('layouts.admin')
@section('content')
    <livewire:admin.post.index>
@endsection
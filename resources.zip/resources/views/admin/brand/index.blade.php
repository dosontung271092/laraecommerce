@extends('layouts.admin')
@section('content')
    <livewire:admin.brand.index>
@endsection
@extends('layouts.admin')
@section('content')
    <livewire:admin.category.index>
@endsection
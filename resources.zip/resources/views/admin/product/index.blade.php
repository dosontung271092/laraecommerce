@extends('layouts.admin')
@section('content')
    <livewire:admin.product.index>
@endsection
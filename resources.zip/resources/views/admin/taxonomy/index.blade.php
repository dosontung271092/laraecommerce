@extends('layouts.admin')
@section('content')
    <livewire:admin.taxonomy.index>
@endsection